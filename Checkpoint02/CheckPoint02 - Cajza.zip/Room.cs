﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02
{
    class Room
    {
        public string Name { get; set; }
        public int SizeInM2 { get; set; }
        public bool LightsOn { get; set; }

        public Room()
        {

        }

    }
}
